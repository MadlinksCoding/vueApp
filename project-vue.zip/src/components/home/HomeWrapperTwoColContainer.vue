<template>
  <div class="home-two-col-container">
    <slot />
  </div>
</template>

<script setup>
</script>
