<template>
  <section class="p-4">
    <h2>{{ $t('pages.home') }}</h2>
    <p>Welcome to the Home section.</p>
  </section>
</template>

<script setup>
</script>
