<template>
  <div class="home-two-col-inner">
    <slot />
  </div>
</template>

<script setup>
</script>
