<template>
  <div class="profile-two-col-inner">
    <slot />
  </div>
</template>

<script setup>
</script>
