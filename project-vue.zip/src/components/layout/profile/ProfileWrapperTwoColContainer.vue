<template>
  <div class="profile-two-col-container">
    <slot />
  </div>
</template>

<script setup>
</script>
