<template>
  <section class="p-4">
    <h2>{{ $t('pages.profile') }}</h2>
    <p>Welcome to the Profile section.</p>
  </section>
</template>

<script setup>
</script>
