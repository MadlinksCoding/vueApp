<template>
  <div class="shop-two-col-container">
    <slot />
  </div>
</template>

<script setup>
</script>
