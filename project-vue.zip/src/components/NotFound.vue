<script setup></script>

<script>
export const assets = {
  critical: [],
  high: [],
  normal: [],
};
</script>

<template>
  <main>
    <h1>404 — Not Found</h1>
    <p>The page you requested cannot be found.</p>
  </main>
</template>
