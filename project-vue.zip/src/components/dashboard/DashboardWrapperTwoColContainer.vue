<template>
  <div class="dashboard-two-col-container">
    <slot />
  </div>
</template>

<script setup>
</script>
