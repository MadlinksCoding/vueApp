<template>
  <div class="dashboard-two-col-inner">
    <slot />
  </div>
</template>

<script setup>
</script>
