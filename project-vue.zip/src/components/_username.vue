<template>
  <div>
    <h1>Profile: @{{ $route.params.username }}</h1>
    <!-- Placeholder, check DB as per dependencies -->
  </div>
</template>
