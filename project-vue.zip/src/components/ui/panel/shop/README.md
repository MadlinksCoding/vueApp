# panel/shop

Placeholder for panel/shop components.
