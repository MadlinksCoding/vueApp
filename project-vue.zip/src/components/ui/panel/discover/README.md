# panel/discover

Placeholder for panel/discover components.
