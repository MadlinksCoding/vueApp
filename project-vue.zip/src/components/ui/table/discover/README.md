# table/discover

Placeholder for table/discover components.
