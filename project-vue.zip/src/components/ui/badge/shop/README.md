# badge/shop

Placeholder for badge/shop components.
