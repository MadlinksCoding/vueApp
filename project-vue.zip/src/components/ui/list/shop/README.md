# list/shop

Placeholder for list/shop components.
