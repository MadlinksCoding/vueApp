# typography/paragraph/shop

Placeholder for typography/paragraph/shop components.
