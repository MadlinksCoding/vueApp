# typography/paragraph/profile

Placeholder for typography/paragraph/profile components.
