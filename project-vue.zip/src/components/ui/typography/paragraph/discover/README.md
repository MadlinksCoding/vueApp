# typography/paragraph/discover

Placeholder for typography/paragraph/discover components.
