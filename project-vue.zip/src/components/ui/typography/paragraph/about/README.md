# typography/paragraph/about

Placeholder for typography/paragraph/about components.
