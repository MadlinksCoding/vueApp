# typography/heading/profile

Placeholder for typography/heading/profile components.
