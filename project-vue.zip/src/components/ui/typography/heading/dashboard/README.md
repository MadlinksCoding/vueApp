# typography/heading/dashboard

Placeholder for typography/heading/dashboard components.
