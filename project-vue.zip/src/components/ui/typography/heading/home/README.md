# typography/heading/home

Placeholder for typography/heading/home components.
