# typography/heading/discover

Placeholder for typography/heading/discover components.
