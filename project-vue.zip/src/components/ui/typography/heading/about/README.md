# typography/heading/about

Placeholder for typography/heading/about components.
