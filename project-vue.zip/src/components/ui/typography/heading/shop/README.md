# typography/heading/shop

Placeholder for typography/heading/shop components.
