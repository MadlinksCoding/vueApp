<template>
  <section class="p-4">
    <h2>{{ $t('pages.contact') }}</h2>
    <p>Welcome to the Contact section.</p>
  </section>
</template>

<script setup>
</script>
