<template>
  <div class="contact-two-col-container">
    <slot />
  </div>
</template>

<script setup>
</script>
