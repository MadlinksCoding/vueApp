<template>
  <div class="contact-two-col-inner">
    <slot />
  </div>
</template>

<script setup>
</script>
