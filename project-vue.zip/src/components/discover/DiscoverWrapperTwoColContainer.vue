<template>
  <div class="discover-two-col-container">
    <slot />
  </div>
</template>

<script setup>
</script>
