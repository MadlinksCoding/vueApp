<template>
  <div class="discover-two-col-inner">
    <slot />
  </div>
</template>

<script setup>
</script>
