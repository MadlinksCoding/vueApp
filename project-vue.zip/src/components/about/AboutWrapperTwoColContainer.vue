<template>
  <div class="about-two-col-container">
    <slot />
  </div>
</template>

<script setup>
</script>
