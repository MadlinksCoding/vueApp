<template>
  <div class="about-two-col-inner">
    <slot />
  </div>
</template>

<script setup>
</script>
