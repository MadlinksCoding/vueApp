<template>
  <section class="p-4">
    <h2>{{ $t('pages.about') }}</h2>
    <p>Welcome to the About section.</p>
  </section>
</template>

<script setup>
</script>
