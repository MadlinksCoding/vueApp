<template>
  <div>
    <h1>Product: {{ $route.params.title }} by @{{ $route.params.username }}</h1>
    <!-- Dynamic placeholder -->
  </div>
</template>
