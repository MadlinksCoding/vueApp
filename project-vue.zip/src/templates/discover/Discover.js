// Discover entry (extend as needed)
export default { name: 'Discover' }
