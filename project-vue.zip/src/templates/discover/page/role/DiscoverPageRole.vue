<template>
  <div class="discover-page-role p-4">
    <p>Discover role-based page content placeholder.</p>
  </div>
</template>

<script setup>
</script>
