<template>
  <aside class="p-4 border-b">
    <p>Discover Sidebar</p>
    <ul>
      <li><RouterLink :to="'/discover'">Discover Home</RouterLink></li>
    </ul>
  </aside>
</template>

<script setup>
</script>
