<template>
  <footer class="p-4 border-b">
    <small>Discover Footer</small>
  </footer>
</template>

<script setup>
</script>
