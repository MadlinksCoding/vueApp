<template>
  <footer class="p-4 border-b">
    <small>Dashboard Footer</small>
  </footer>
</template>

<script setup>
</script>
