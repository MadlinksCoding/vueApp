<template>
    <p>This is payout settings in dashboard for agent</p>
</template>

<script>

</script>