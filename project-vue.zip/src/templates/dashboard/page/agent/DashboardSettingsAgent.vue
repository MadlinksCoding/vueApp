<template>
    <p>This is dashboard settings for agent</p>
</template>

<script>

</script>