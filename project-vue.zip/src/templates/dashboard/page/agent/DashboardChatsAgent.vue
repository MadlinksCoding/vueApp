<template>
    <p>This is dashboard chat page for Agent</p>
</template>

<script>

</script>