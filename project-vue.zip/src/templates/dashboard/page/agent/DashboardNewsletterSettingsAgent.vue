<template>
    <p>This is newsletters settings in dashboard for agent</p>
</template>

<script>

</script>