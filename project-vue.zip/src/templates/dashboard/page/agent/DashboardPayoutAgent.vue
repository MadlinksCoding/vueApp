<template>
    <p>This is payout in dashboard for agent</p>
</template>

<script>

</script>