<template>
    <p>This is dashboard live stream settings for creator</p>
</template>

<script>

</script>