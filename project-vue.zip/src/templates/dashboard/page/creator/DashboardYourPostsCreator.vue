<template>
    <p>This is your posts in dashboard for creator</p>
</template>

<script>

</script>