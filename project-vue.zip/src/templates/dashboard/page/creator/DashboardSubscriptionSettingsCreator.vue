<template>
    <p>This is dashboard subscription settings for creator</p>
</template>

<script>

</script>