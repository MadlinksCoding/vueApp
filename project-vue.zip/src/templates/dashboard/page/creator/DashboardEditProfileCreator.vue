<template>
    <p>This is edit profile in dashboard for creator</p>
</template>

<script>

</script>