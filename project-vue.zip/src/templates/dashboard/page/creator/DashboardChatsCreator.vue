<template>
    <p>This is dashboard chat page for Creator</p>
</template>

<script>

</script>