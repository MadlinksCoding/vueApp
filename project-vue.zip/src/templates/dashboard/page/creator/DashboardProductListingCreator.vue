<template>
    <p>This is product listings in dashboard for creator</p>
</template>

<script>

</script>