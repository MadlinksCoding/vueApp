<template>
    <p>This is dashboard call and chat settings for creator</p>
</template>

<script>

</script>