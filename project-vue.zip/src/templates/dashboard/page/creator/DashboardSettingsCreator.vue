<template>
    <p>This is dashboard settings for creator</p>
</template>

<script>

</script>