<template>
    <p>This is newsletter setting in dashboard for creator</p>
</template>

<script>

</script>