<template>
    <p>This is private chat settings in dashboard for creator</p>
</template>

<script>

</script>