<template>
    <p>This is dashboard subscription for creator</p>
</template>

<script>

</script>