<template>
    <p>This is custom product settings in dashboard for creator</p>
</template>

<script>

</script>