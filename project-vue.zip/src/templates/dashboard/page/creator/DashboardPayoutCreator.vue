<template>
    <p>This is payout in dashboard for creator</p>
</template>

<script>

</script>