<template>
    <p>This is custom product requests in dashboard for creator</p>
</template>

<script>

</script>