<template>
    <p>This is payout settings in dashboard for creator</p>
</template>

<script>

</script>