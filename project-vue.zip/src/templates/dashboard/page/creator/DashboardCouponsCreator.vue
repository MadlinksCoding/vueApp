<template>
    <p>This is dashboard coupons page for creators</p>
</template>

<script>

</script>