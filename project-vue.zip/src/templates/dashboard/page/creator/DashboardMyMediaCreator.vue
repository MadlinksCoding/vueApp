<template>
    <p>This is dashboard my media for creator</p>
</template>

<script>

</script>