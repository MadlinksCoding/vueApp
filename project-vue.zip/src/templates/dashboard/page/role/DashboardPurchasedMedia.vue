<template>
    <p>This is purchased media in dashboard for global</p>
</template>

<script>

</script>