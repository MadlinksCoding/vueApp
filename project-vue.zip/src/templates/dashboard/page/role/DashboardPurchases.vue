<template>
    <p>This is purchases in dashboard for global</p>
</template>

<script>

</script>