<template>
    <p>This is shipping in dashboard for global</p>
</template>

<script>

</script>