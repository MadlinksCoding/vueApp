<template>
  <p>This is dashboard privacy security for global</p>  
</template>

<script>

</script>
