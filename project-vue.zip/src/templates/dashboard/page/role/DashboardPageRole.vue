<template>
  <div class="dashboard-page-role p-4">
    <p>Dashboard role-based page content placeholder.</p>
  </div>
</template>

<script setup>
</script>
