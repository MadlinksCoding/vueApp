<template>
  <p>This is dashboard change password for global</p>  
</template>

<script>

</script>
