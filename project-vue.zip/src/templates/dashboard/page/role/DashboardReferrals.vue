<template>
    <p>This is referrals in dashboard for global</p>
</template>

<script>

</script>