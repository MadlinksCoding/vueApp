<template>
  <p>This is dashboard following for global</p>  
</template>

<script>

</script>
