<template>
    <p>This is dashboard settings for fan</p>
</template>

<script>

</script>