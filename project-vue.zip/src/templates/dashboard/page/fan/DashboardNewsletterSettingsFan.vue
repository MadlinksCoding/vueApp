<template>
    <p>This is newsletter settings in dashboard for fan</p>
</template>

<script>

</script>