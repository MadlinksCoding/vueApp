<template>
    <p>This is dashboard coupons page for fan</p>
</template>

<script>

</script>