<template>
    <p>This is custom product requests in dashboard for fan</p>
</template>

<script>

</script>