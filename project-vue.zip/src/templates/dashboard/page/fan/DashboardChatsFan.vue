<template>
    <p>This is dashboard chat page for Fan</p>
</template>

<script>

</script>