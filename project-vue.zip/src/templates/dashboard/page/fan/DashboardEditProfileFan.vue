<template>
    <p>This is edit profile in dashboard for fan</p>
</template>

<script>

</script>