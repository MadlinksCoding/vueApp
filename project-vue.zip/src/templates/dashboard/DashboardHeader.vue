<template>
  <header class="p-4 border-b">
    <h1>Dashboard Header</h1>
  </header>
</template>

<script setup>
</script>
