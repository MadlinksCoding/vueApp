<template>
  <aside class="p-4 border-b">
    <p>Dashboard Sidebar</p>
    <ul>
      <li><RouterLink :to="'/dashboard'">Dashboard Home</RouterLink></li>
    </ul>
  </aside>
</template>

<script setup>
</script>
