<template>
    <p>This is facebook auth for global</p>
</template>

<script>

</script>