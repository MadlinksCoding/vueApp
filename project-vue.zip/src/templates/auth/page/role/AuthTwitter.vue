<template>
    <p>This is twitter auth for global</p>
</template>

<script>

</script>