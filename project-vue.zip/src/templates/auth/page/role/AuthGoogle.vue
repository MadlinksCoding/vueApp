<template>
    <p>This is google auth for global</p>
</template>

<script>

</script>