<template>
  <aside class="p-4 border-b">
    <p>Profile Sidebar</p>
    <ul>
      <li><RouterLink :to="'/profile'">Profile Home</RouterLink></li>
    </ul>
  </aside>
</template>

<script setup>
</script>
