// Profile entry (extend as needed)
export default { name: 'Profile' }
