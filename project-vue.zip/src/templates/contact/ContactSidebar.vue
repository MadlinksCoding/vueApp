<template>
  <aside class="p-4 border-b">
    <p>Contact Sidebar</p>
    <ul>
      <li><RouterLink :to="'/contact'">Contact Home</RouterLink></li>
    </ul>
  </aside>
</template>

<script setup>
</script>
