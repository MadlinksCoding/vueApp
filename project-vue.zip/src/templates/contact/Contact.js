// Contact entry (extend as needed)
export default { name: 'Contact' }
