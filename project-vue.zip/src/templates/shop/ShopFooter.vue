<template>
  <footer class="p-4 border-b">
    <small>Shop Footer</small>
  </footer>
</template>

<script setup>
</script>
