<template>
  <aside class="p-4 border-b">
    <p>Shop Sidebar</p>
    <ul>
      <li><RouterLink :to="'/shop'">Shop Home</RouterLink></li>
    </ul>
  </aside>
</template>

<script setup>
</script>
