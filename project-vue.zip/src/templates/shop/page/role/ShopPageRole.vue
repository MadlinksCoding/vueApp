<template>
  <div class="shop-page-role p-4">
    <p>Shop role-based page content placeholder.</p>
  </div>
</template>

<script setup>
</script>
