// About entry (extend as needed)
export default { name: 'About' }
