<template>
  <aside class="p-4 border-b">
    <p>About Sidebar</p>
    <ul>
      <li><RouterLink :to="'/about'">About Home</RouterLink></li>
    </ul>
  </aside>
</template>

<script setup>
</script>
