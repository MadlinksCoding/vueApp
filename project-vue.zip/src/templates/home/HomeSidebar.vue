<template>
  <aside class="p-4 border-b">
    <p>Home Sidebar</p>
    <ul>
      <li><RouterLink :to="'/home'">Home Home</RouterLink></li>
    </ul>
  </aside>
</template>

<script setup>
</script>
