<template>
  <footer class="p-4 border-b">
    <small>Home Footer</small>
  </footer>
</template>

<script setup>
</script>
