// Home entry (extend as needed)
export default { name: 'Home' }
