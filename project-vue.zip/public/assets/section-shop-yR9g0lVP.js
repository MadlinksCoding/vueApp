import{_ as e}from"./section-auth-BNoliYnU.js";import{c as t,o as a,a as s}from"./vendor-CsUw8uuj.js";const _={critical:[],high:["/js/shop-cart.js"],normal:[]},n={};function r(c,o,p,l,i,m){return a(),t("main",null,o[0]||(o[0]=[s("h1",null,"Shop",-1),s("p",null,"Shop page",-1)]))}const d=e(n,[["render",r]]);export{_ as assets,d as default};
//# sourceMappingURL=section-shop-yR9g0lVP.js.map
