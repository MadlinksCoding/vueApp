import{_ as e}from"./section-auth-BzJl3yVB.js";import{c as t,o as a,a as s}from"./vendor-BSgqbTD8.js";const _={critical:[],high:["/js/shop-cart.js"],normal:[]},n={};function r(c,o,p,l,i,m){return a(),t("main",null,o[0]||(o[0]=[s("h1",null,"Shop",-1),s("p",null,"Shop page",-1)]))}const d=e(n,[["render",r]]);export{_ as assets,d as default};
//# sourceMappingURL=section-shop-Btav5iZ3.js.map
