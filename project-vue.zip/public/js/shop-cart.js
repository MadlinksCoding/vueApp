console.log("Vendor charts JS loaded!");
